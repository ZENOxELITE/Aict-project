from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from groq import Groq

app = Flask(__name__, static_folder=".")
CORS(app)

client = Groq(api_key="your_api_key_here")

conversation_history = []

VALID_MODELS = [
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "qwen-qwq-32b",
    "gemma2-9b-it",
    "mixtral-8x7b-32768",
]

def call_ai(messages, model="llama-3.3-70b-versatile", max_tokens=2048, temperature=0.7):
    if model not in VALID_MODELS:
        model = "llama-3.3-70b-versatile"
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return response.choices[0].message.content, response.usage.total_tokens if response.usage else None

# ── Chat ──
@app.route("/")
def index():
    return send_from_directory(".", "index.html")

@app.route("/tools")
def tools():
    return send_from_directory(".", "tools.html")

@app.route("/chat", methods=["POST"])
def chat():
    global conversation_history
    data = request.json
    user_message = data.get("message", "").strip()
    model = data.get("model", "meta-llama/llama-4-scout-17b-16e-instruct")

    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    if len(conversation_history) > 20:
        conversation_history = conversation_history[-20:]

    conversation_history.append({"role": "user", "content": user_message})

    try:
        reply, tokens = call_ai(conversation_history, model=model)
        conversation_history.append({"role": "assistant", "content": reply})
        return jsonify({"reply": reply, "model": model, "tokens": tokens})
    except Exception as e:
        conversation_history.pop()
        err = str(e)
        if "rate_limit" in err.lower():
            return jsonify({"error": "Rate limit hit. Wait a moment and retry."}), 429
        elif "invalid_api_key" in err.lower():
            return jsonify({"error": "Invalid API key."}), 401
        else:
            return jsonify({"error": f"AI error: {err}"}), 500

# ── Summarize ──
@app.route("/summarize", methods=["POST"])
def summarize():
    data = request.json
    text = data.get("text", "").strip()
    style = data.get("style", "concise")   # concise | detailed | bullet | eli5
    model = data.get("model", "llama-3.3-70b-versatile")

    if not text:
        return jsonify({"error": "No text provided"}), 400
    if len(text) > 15000:
        return jsonify({"error": "Text too long. Max 15,000 characters."}), 400

    style_prompts = {
        "concise":  "Summarize the following text in 3-5 concise sentences. Be clear and to the point.",
        "detailed": "Write a detailed summary of the following text. Cover all key points, arguments, and conclusions in well-structured paragraphs.",
        "bullet":   "Summarize the following text as a clean bullet-point list. Each bullet should be one key idea. Use • as the bullet symbol.",
        "eli5":     "Explain the following text simply, as if explaining to a 10-year-old. Use simple words, short sentences, and easy examples.",
    }

    prompt = style_prompts.get(style, style_prompts["concise"])

    try:
        reply, tokens = call_ai([
            {"role": "system", "content": prompt},
            {"role": "user", "content": text}
        ], model=model, max_tokens=1024, temperature=0.4)
        return jsonify({"summary": reply, "tokens": tokens, "word_count": len(text.split())})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Story ──
@app.route("/story", methods=["POST"])
def story():
    data = request.json
    prompt_text  = data.get("prompt", "").strip()
    genre        = data.get("genre", "adventure")
    length       = data.get("length", "medium")    # short | medium | long
    tone         = data.get("tone", "neutral")      # dark | funny | romantic | neutral | suspense
    protagonist  = data.get("protagonist", "")
    setting      = data.get("setting", "")
    model        = data.get("model", "llama-3.3-70b-versatile")
    continue_story = data.get("continue_story", "")  # for story continuation

    if not prompt_text and not continue_story:
        return jsonify({"error": "Please provide a story prompt"}), 400

    length_map = {"short": "400-600 words", "medium": "700-1000 words", "long": "1200-1600 words"}
    word_target = length_map.get(length, "700-1000 words")

    extras = []
    if protagonist: extras.append(f"Main character: {protagonist}")
    if setting: extras.append(f"Setting: {setting}")
    extra_str = ". ".join(extras) + "." if extras else ""

    if continue_story:
        system_msg = f"""You are a creative writer. Continue the following story naturally.
Keep the same tone, style, and characters. Add {word_target} to the story.
Genre: {genre}. Tone: {tone}. {extra_str}
Do NOT summarize what happened — just continue writing the story from where it left off."""
        user_msg = f"Continue this story:\n\n{continue_story}"
    else:
        system_msg = f"""You are a creative fiction writer. Write an engaging {genre} story.
Length: {word_target}. Tone: {tone}. {extra_str}
Structure: Opening hook → Rising action → Climax → Resolution.
Use vivid descriptions, strong dialogue, and keep the reader engaged throughout."""
        user_msg = f"Write a story about: {prompt_text}"

    try:
        reply, tokens = call_ai([
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_msg}
        ], model=model, max_tokens=2048, temperature=0.85)
        return jsonify({"story": reply, "tokens": tokens})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ── Misc ──
@app.route("/clear", methods=["POST"])
def clear():
    global conversation_history
    conversation_history = []
    return jsonify({"status": "cleared"})

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "history_length": len(conversation_history)})

@app.route("/models", methods=["GET"])
def models():
    return jsonify({"models": VALID_MODELS})

if __name__ == "__main__":
    app.run(debug=True, port=5001)
